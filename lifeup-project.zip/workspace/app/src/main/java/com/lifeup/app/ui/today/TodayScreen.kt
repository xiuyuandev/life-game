package com.lifeup.app.ui.today

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.material3.pulltorefresh.rememberPullToRefreshState
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.lifeup.app.ui.components.doneKeyboardActions
import com.lifeup.app.ui.components.doneKeyboardOptions
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import com.lifeup.app.data.db.Priority
import com.lifeup.app.ui.components.DismissBackground
import com.lifeup.app.ui.components.ErrorState
import com.lifeup.app.ui.components.ScrollToTopButton
import com.lifeup.app.ui.components.TodoItem
import com.lifeup.app.ui.feedback.DailyQuote
import com.lifeup.app.ui.feedback.rememberHapticController
import com.lifeup.app.ui.feedback.rememberSoundController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TodayScreen(
    onNavigateToTimer: (Long) -> Unit,
    onNavigateToCreateSkill: () -> Unit,
    onNavigateToRetroactive: () -> Unit = {},
    onNavigateToCharacter: () -> Unit = {},
    onNavigateToLedger: () -> Unit = {},
    onNavigateToDemonList: () -> Unit = {},
    viewModel: TodayViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val haptic = rememberHapticController(viewModel.settingsPrefs)
    val sound = rememberSoundController(viewModel.settingsPrefs)
    var showAddDialog by remember { mutableStateOf(false) }
    var addAsHabit by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    var fabExpanded by remember { mutableStateOf(false) }

    Scaffold(
        floatingActionButton = {
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Expanded menu items
                androidx.compose.animation.AnimatedVisibility(
                    visible = fabExpanded,
                    enter = fadeIn() + slideInVertically(initialOffsetY = { it / 2 }),
                    exit = fadeOut() + slideOutVertically(targetOffsetY = { it / 2 })
                ) {
                    Column(
                        horizontalAlignment = Alignment.End,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Retroactive entry
                        SmallFabItem(
                            label = "补录时间",
                            icon = Icons.Default.History,
                            onClick = {
                                fabExpanded = false
                                onNavigateToRetroactive()
                            }
                        )
                        // Quick timer
                        SmallFabItem(
                            label = "开始计时",
                            icon = Icons.Default.Timer,
                            onClick = {
                                fabExpanded = false
                                // Navigate to timer with first skill or -1 for selection
                                onNavigateToTimer(-1L)
                            }
                        )
                        // Add todo
                        SmallFabItem(
                            label = "添加待办",
                            icon = Icons.Default.Add,
                            onClick = {
                                fabExpanded = false
                                addAsHabit = false
                                showAddDialog = true
                            }
                        )
                    }
                }

                // Main FAB
                FloatingActionButton(
                    onClick = {
                        haptic.light()
                        sound.tap()
                        fabExpanded = !fabExpanded
                    },
                    containerColor = MaterialTheme.colorScheme.primary,
                    shape = RoundedCornerShape(16.dp),
                    elevation = FloatingActionButtonDefaults.elevation(
                        defaultElevation = 4.dp,
                        hoveredElevation = 8.dp
                    )
                ) {
                    val rotation by androidx.compose.animation.core.animateFloatAsState(
                        targetValue = if (fabExpanded) 45f else 0f,
                        animationSpec = androidx.compose.animation.core.tween(200),
                        label = "fabRotation"
                    )
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = if (fabExpanded) "关闭" else "更多操作",
                        modifier = Modifier
                            .size(24.dp)
                            .graphicsLayer { rotationZ = rotation }
                    )
                }
            }
        }
    ) { innerPadding ->
        val pullToRefreshState = rememberPullToRefreshState()
        PullToRefreshBox(
            state = pullToRefreshState,
            isRefreshing = uiState.isRefreshing,
            onRefresh = { viewModel.refresh() },
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (uiState.isLoading) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            } else if (uiState.error != null) {
                ErrorState(
                    message = uiState.error,
                    onRetry = { viewModel.refresh() },
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Top hero: greeting + date + energy ring + streak + daily quote
                item {
                    TodayHeroSection(
                        characterLevel = uiState.characterLevel,
                        energyCurrent = uiState.energy,
                        energyCap = uiState.energyCap,
                        streakDays = uiState.streakCount,
                        quote = DailyQuote.forDate()
                    )
                }

                // Tip card
                AnimatedVisibility(
                    visible = uiState.tip != null,
                    enter = fadeIn() + slideInVertically(),
                    exit = fadeOut() + slideOutVertically()
                ) {
                    if (uiState.tip != null) {
                        TipCard(
                            tip = uiState.tip,
                            onDismiss = { viewModel.dismissTip() }
                        )
                    }
                }

                // Today's stats overview
                item {
                    TodayStatsOverview(
                        investmentMinutes = uiState.investmentMinutes,
                        consumptionMinutes = uiState.consumptionMinutes,
                        goldEarned = uiState.goldEarned,
                        goldSpent = uiState.goldSpent,
                        habitsCompleted = uiState.habitsCompleted,
                        todosCompleted = uiState.todosCompleted,
                        characterLevel = uiState.characterLevel,
                        totalExp = uiState.totalExp,
                        expToNextLevel = uiState.expToNextLevel,
                        streakCount = uiState.streakCount,
                        onNavigateToCharacter = onNavigateToCharacter,
                        onNavigateToLedger = onNavigateToLedger
                    )
                }

                // 心魔试炼快捷入口
                item {
                    com.lifeup.app.ui.demon.DemonEntryCard(onClick = onNavigateToDemonList)
                }

                // Habit section
                item {
                    SectionHeader(
                        title = "习惯打卡",
                        icon = "🔄",
                        onAddClick = {
                            addAsHabit = true
                            showAddDialog = true
                        }
                    )
                }

                if (uiState.habits.isEmpty()) {
                    item {
                        EmptyStateMessage(text = "还没有习惯，添加一个吧", icon = "🌱")
                    }
                } else {
                    items(
                        items = uiState.habits,
                        key = { "habit-${it.id}" }
                    ) { habit ->
                        val dismissState = rememberSwipeToDismissBoxState(
                            confirmValueChange = { dismissValue ->
                                if (dismissValue == SwipeToDismissBoxValue.StartToEnd || dismissValue == SwipeToDismissBoxValue.EndToStart) {
                                    viewModel.deleteTodo(habit.id)
                                    true
                                } else false
                            }
                        )
                        SwipeToDismissBox(
                            state = dismissState,
                            backgroundContent = { DismissBackground(dismissState) },
                            modifier = Modifier.animateItemPlacement()
                        ) {
                            TodoItem(
                                todo = habit,
                                onToggle = {
                                    haptic.tick()
                                    sound.tap()
                                    viewModel.toggleTodo(habit.id)
                                },
                                onDelete = { viewModel.deleteTodo(habit.id) }
                            )
                        }
                    }
                }

                // Spacer between sections
                item { Spacer(modifier = Modifier.height(8.dp)) }

                // Todo section
                item {
                    SectionHeader(
                        title = "今日待办",
                        icon = "📋",
                        onAddClick = {
                            addAsHabit = false
                            showAddDialog = true
                        }
                    )
                }

                if (uiState.todos.isEmpty()) {
                    item {
                        EmptyStateMessage(text = "今天没有待办", icon = "✨")
                    }
                } else {
                    items(
                        items = uiState.todos,
                        key = { "todo-${it.id}" }
                    ) { todo ->
                        val dismissState = rememberSwipeToDismissBoxState(
                            confirmValueChange = { dismissValue ->
                                if (dismissValue == SwipeToDismissBoxValue.StartToEnd || dismissValue == SwipeToDismissBoxValue.EndToStart) {
                                    viewModel.deleteTodo(todo.id)
                                    true
                                } else false
                            }
                        )
                        SwipeToDismissBox(
                            state = dismissState,
                            backgroundContent = { DismissBackground(dismissState) },
                            modifier = Modifier.animateItemPlacement()
                        ) {
                            TodoItem(
                                todo = todo,
                                onToggle = {
                                    haptic.tick()
                                    sound.tap()
                                    viewModel.toggleTodo(todo.id)
                                },
                                onDelete = { viewModel.deleteTodo(todo.id) }
                            )
                        }
                    }
                }

                // Quick actions row
                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    QuickActionsRow(
                        onRetroactiveClick = onNavigateToRetroactive,
                        onStartTimerClick = { onNavigateToTimer(0L) }
                    )
                }

                // Bottom spacing for FAB
                item { Spacer(modifier = Modifier.height(72.dp)) }
            }
            }

            ScrollToTopButton(
                listState = listState,
                onClick = {
                    viewModel.viewModelScope.launch {
                        listState.animateScrollToItem(0)
                    }
                }
            )
        }
    }

    // Add todo/habit dialog
    if (showAddDialog) {
        AddTodoSheet(
            isHabit = addAsHabit,
            onDismiss = { showAddDialog = false },
            onConfirm = { title, priority, linkedSkillId ->
                viewModel.addTodo(
                    title = title,
                    isHabit = addAsHabit,
                    priority = priority,
                    linkedSkillId = linkedSkillId
                )
                showAddDialog = false
            }
        )
    }
}

@Composable
private fun SectionHeader(
    title: String,
    icon: String = "",
    onAddClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icon.isNotEmpty()) {
                Text(text = icon, style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.width(6.dp))
            }
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
        TextButton(onClick = onAddClick) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = "添加",
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(2.dp))
            Text("添加", style = MaterialTheme.typography.labelMedium)
        }
    }
}

@Composable
private fun EmptyStateMessage(text: String, icon: String = "") {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 24.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icon.isNotEmpty()) {
                Text(text = icon, style = MaterialTheme.typography.bodyLarge)
                Spacer(modifier = Modifier.width(6.dp))
            }
            Text(
                text = text,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
            )
        }
    }
}

@Composable
private fun QuickActionsRow(
    onRetroactiveClick: () -> Unit,
    onStartTimerClick: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        OutlinedButton(
            onClick = onRetroactiveClick,
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.outlinedButtonColors(
                contentColor = MaterialTheme.colorScheme.onSurfaceVariant
            )
        ) {
            Icon(
                imageVector = Icons.Default.History,
                contentDescription = "补录时间",
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text("补录时间")
        }

        Button(
            onClick = onStartTimerClick,
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary
            )
        ) {
            Icon(
                imageVector = Icons.Default.Timer,
                contentDescription = "开始计时",
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text("开始计时")
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddTodoSheet(
    isHabit: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (title: String, priority: Priority, linkedSkillId: Long?) -> Unit
) {
    val sheetState = rememberModalBottomSheetState()
    var title by remember { mutableStateOf("") }
    var selectedPriority by remember { mutableStateOf(Priority.NONE) }

    val focusRequester = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current

    LaunchedEffect(Unit) {
        try {
            focusRequester.requestFocus()
        } catch (_: Exception) { }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        windowInsets = WindowInsets.ime
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .imePadding()
                .padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = if (isHabit) "添加习惯" else "添加待办",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )

            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = {
                    Text(if (isHabit) "习惯名称" else "待办名称")
                },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .focusRequester(focusRequester),
                shape = RoundedCornerShape(12.dp),
                keyboardOptions = doneKeyboardOptions(),
                keyboardActions = doneKeyboardActions(focusManager) {
                    if (title.isNotBlank()) {
                        onConfirm(title, selectedPriority, null)
                    }
                }
            )

            // Priority selector
            Text(
                text = "优先级",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Priority.entries.forEach { priority ->
                    val isSelected = selectedPriority == priority
                    val color = when (priority) {
                        Priority.HIGH -> Color(0xFFFF5252)
                        Priority.MEDIUM -> Color(0xFFFFB300)
                        Priority.LOW -> Color(0xFF66BB6A)
                        Priority.NONE -> Color(0xFFBDBDBD)
                    }
                    val label = when (priority) {
                        Priority.HIGH -> "高"
                        Priority.MEDIUM -> "中"
                        Priority.LOW -> "低"
                        Priority.NONE -> "无"
                    }

                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedPriority = priority },
                        label = { Text(label) },
                        color = color
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(onClick = onDismiss) {
                    Text("取消")
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = {
                        onConfirm(title, selectedPriority, null)
                    },
                    enabled = title.isNotBlank(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("确定")
                }
            }
        }
    }
}

@Composable
private fun FilterChip(
    selected: Boolean,
    onClick: () -> Unit,
    label: @Composable () -> Unit,
    color: Color
) {
    val containerColor = if (selected) color.copy(alpha = 0.15f) else Color.Transparent
    val borderColor = if (selected) color else MaterialTheme.colorScheme.outlineVariant
    val contentColor = if (selected) color else MaterialTheme.colorScheme.onSurfaceVariant

    OutlinedButton(
        onClick = onClick,
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = containerColor,
            contentColor = contentColor
        ),
        border = BorderStroke(1.dp, borderColor),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
        shape = RoundedCornerShape(8.dp)
    ) {
        label()
    }
}

@Composable
private fun TodayStatsOverview(
    investmentMinutes: Int,
    consumptionMinutes: Int,
    goldEarned: Int,
    goldSpent: Int,
    habitsCompleted: Int,
    todosCompleted: Int,
    characterLevel: Int,
    totalExp: Long,
    expToNextLevel: Long,
    streakCount: Int,
    onNavigateToCharacter: () -> Unit,
    onNavigateToLedger: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            // Top row: Character level + streak
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Character level chip
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer)
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .clickable(onClick = onNavigateToCharacter)
                ) {
                    Text(
                        text = "⭐",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Lv.$characterLevel",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "(${totalExp} XP)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f)
                    )
                }

                // Streak chip
                if (streakCount > 0) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.tertiaryContainer)
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "🔥",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${streakCount}天",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onTertiaryContainer
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Stats grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatItem(
                    icon = "📈",
                    label = "投资",
                    value = "${investmentMinutes}分",
                    modifier = Modifier.weight(1f)
                )
                StatItem(
                    icon = "📉",
                    label = "消耗",
                    value = "${consumptionMinutes}分",
                    modifier = Modifier.weight(1f)
                )
                StatItem(
                    icon = "💰",
                    label = "金币",
                    value = "${goldEarned - goldSpent}",
                    modifier = Modifier.weight(1f)
                )
                StatItem(
                    icon = "✅",
                    label = "完成",
                    value = "${habitsCompleted + todosCompleted}",
                    modifier = Modifier.weight(1f)
                )
            }

            // Exp progress bar
            if (expToNextLevel > 0) {
                Spacer(modifier = Modifier.height(10.dp))
                val progress = if (expToNextLevel > 0) {
                    val currentLevelThreshold = com.lifeup.app.domain.calculator.AttributeCalculator.getLevelThreshold(characterLevel)
                    val nextThreshold = com.lifeup.app.domain.calculator.AttributeCalculator.getLevelThreshold(characterLevel + 1)
                    val levelRange = (nextThreshold - currentLevelThreshold).toFloat()
                    val currentInLevel = (totalExp - currentLevelThreshold).toFloat()
                    (currentInLevel / levelRange).coerceIn(0f, 1f)
                } else 0f

                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(4.dp)
                        .clip(RoundedCornerShape(2.dp)),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "升级还需 ${expToNextLevel} XP",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
private fun StatItem(
    icon: String,
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            .padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = icon,
            style = MaterialTheme.typography.bodyMedium
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun SmallFabItem(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.8f))
                .padding(horizontal = 10.dp, vertical = 4.dp)
        )
        androidx.compose.material3.SmallFloatingActionButton(
            onClick = onClick,
            containerColor = MaterialTheme.colorScheme.secondaryContainer,
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}
